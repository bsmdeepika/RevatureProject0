package com.revature.bankapp;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.revature.bankapp.model.BankApplication;
import com.revature.bankapp.util.DBUtil;

public class BankAppDAOImplTest {

	@Test
	public void testGetAllAccounts() throws Exception {
		//fail("Not yet implemented");
		boolean flag=false;
		List<BankApplication> bankapplicationlist=new ArrayList<BankApplication>();
		try {
		Connection con= DBUtil.getConnection();
		
		Statement pst = con.createStatement();
		ResultSet rs = pst.executeQuery("select * from BankApplication");
			
	
			if(rs.next())
				flag=true;
	}
			catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
