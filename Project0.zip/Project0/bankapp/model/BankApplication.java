package com.revature.bankapp.model;

public class BankApplication {
	private int accountId;
	private String name;
	private int mobile;
	private String city;
	private int balance;
	
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMobile() {
		return mobile;
	}
	@Override
	public String toString() {
		return "BankApplication [accountId=" + accountId + ", name=" + name + ", mobile=" + mobile + ", city=" + city
				+ ", balance=" + balance + "]";
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	

}
