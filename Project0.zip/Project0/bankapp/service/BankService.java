package com.revature.bankapp.service;
import java.util.List;

import com.revature.bankapp.model.BankApplication;

public interface BankService {
	public void createAccount();
	public void deposite();
	public void withdraw();
	public void transfer();
	public List<BankApplication> getAllAccounts();
}
