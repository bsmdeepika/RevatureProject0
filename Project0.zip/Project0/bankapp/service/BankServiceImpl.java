package com.revature.bankapp.service;
import com.revature.bankapp.model.BankApplication;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.revature.bankapp.dao.BankAppDAO;
import com.revature.bankapp.dao.BankAppDAOImpl;

public class BankServiceImpl implements BankService {
	BankAppDAO bankAppDaoImpl=new BankAppDAOImpl();
	static Logger logger= Logger.getLogger(BankServiceImpl.class);
	
	
	public void createAccount() {
		logger.info("in service....deposite method");
		try {
			bankAppDaoImpl.createAccount();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void deposite() {
		logger.info("in service....deposite method");
		try {
			bankAppDaoImpl.deposite();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void withdraw() {
		logger.info("in...service......withdraw method");
		try {
			bankAppDaoImpl.withdraw();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void transfer() {
		logger.info("in service........trasfer method");
		try {
			bankAppDaoImpl.transfer();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public List<BankApplication> getAllAccounts(){	
		logger.info("in service......get all account holders method");
		return bankAppDaoImpl.getAllAccounts();
	}
	
}
