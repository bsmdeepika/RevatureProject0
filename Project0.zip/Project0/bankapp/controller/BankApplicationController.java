package com.revature.bankapp.controller;
import java.util.List;

import com.revature.bankapp.model.BankApplication;
import com.revature.bankapp.service.BankService;
import com.revature.bankapp.service.BankServiceImpl;


public class BankApplicationController {
	BankService bankApplicationServiceImpl=new BankServiceImpl();
	public void createAccount() {
		try {
			bankApplicationServiceImpl.createAccount();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deposite() {
		try {
			bankApplicationServiceImpl.deposite();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void withdraw() {
		try {
			bankApplicationServiceImpl.withdraw();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void transfer() {
		try {
			bankApplicationServiceImpl.transfer();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public List<BankApplication> getAllAccounts(){
		return bankApplicationServiceImpl.getAllAccounts();
	}
	

}
