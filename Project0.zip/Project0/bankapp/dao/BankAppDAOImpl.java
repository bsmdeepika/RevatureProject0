package com.revature.bankapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.revature.bankapp.model.BankApplication;
import com.revature.bankapp.util.DBUtil;

public class BankAppDAOImpl implements BankAppDAO {
	BankApplication bankapplication=new BankApplication();
	Scanner s=new Scanner(System.in);
	public void createAccount() {
		System.out.println("Enter Bank Account Details");
		BankApplication bankapplication=new BankApplication();
		System.out.println("Enter id");
		int accountId=s.nextInt();
		s.nextLine();
		System.out.println("Enter name:");
		String name=s.nextLine();
		System.out.println("Enter mobile number");
		int mobile=s.nextInt();
		s.nextLine();
		System.out.println("Enter city");
		String city=s.nextLine();
		System.out.println("Enter balance");
		int balance=s.nextInt();
		s.nextLine();
		bankapplication.setAccountId(accountId);
		bankapplication.setName(name);
		bankapplication.setMobile(mobile);
		bankapplication.setCity(city);
		bankapplication.setBalance(balance);
		try {
			Connection con=DBUtil.getConnection();
			Statement st=con.createStatement();
			PreparedStatement pst=con.prepareStatement("insert into BANKING values(?,?,?,?,?)");
			pst.setInt(1,bankapplication.getAccountId());
			pst.setString(2,bankapplication.getName());
			pst.setInt(3,bankapplication.getMobile());
			pst.setString(4,bankapplication.getCity());
			pst.setInt(5,bankapplication.getBalance());
			pst.execute();
			System.out.println("Account created Successfully...........");}
			
		catch (Exception e) {
			// TODO Auto-generated catch blo
			e.printStackTrace();
		}
}
	
		
	public void withdraw() {
		try {
			Connection con=DBUtil.getConnection();
			System.out.println("Enter Amount to make withdraw:");
			int amount=s.nextInt();
			s.nextLine();
			System.out.println("Enter AccountID:");
			int Accountid=s.nextInt();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select AccountId from BANKING");
			boolean flag=false;
			while(rs.next()) {
			if( rs.getInt(1)==Accountid) {
			PreparedStatement pst=con.prepareStatement("update BANKING set balance=balance-? where AccountId=? and balance>=?" );
			pst.setInt(1,amount);
			pst.setInt(2, Accountid);
			pst.setInt(3, amount);
			pst.executeUpdate();
			System.out.println("Withdraw Successful.....");
			flag=true;
			}
			else {
				flag=false;
			}
			}
			
			if(flag==false) {
				System.out.println("Sorry....The operation can not be done due to insufficient balance or invalid account number.");
				
			}
			
			
	} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void deposite() {
		boolean flag=false;
		try {
			Connection con=DBUtil.getConnection();
			System.out.println("Enter AccountID:");
			int Accountid=s.nextInt();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select AccountId , balance from BANKING");
			while(rs.next()) {
			if(rs.getInt(1)==Accountid){
			System.out.println("Enter Amount to make Deposite:");
			int amount=s.nextInt();
			PreparedStatement pst=con.prepareStatement("update BANKING set balance=balance+? where AccountId=?");
			pst.setInt(1,amount);
			pst.setInt(2, Accountid);
			pst.executeUpdate();
			
			System.out.println("Deposited Successfully.........");
			flag=true;
			}
		} 
			if(flag==false) {
				System.out.println("Something went wrong....Check the details.");
			}
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	public void transfer(){
		//First we need to withdraw
		boolean flag=false;
		System.out.println("Enter Amount to Transfer:");
		int amount=s.nextInt();
		s.nextLine();
		try {
		Connection con;
			con = DBUtil.getConnection();
		System.out.println("Enter AccountID of sender:");
		int Accountid=s.nextInt();
		Statement st;
			st = con.createStatement();
		ResultSet rs=st.executeQuery("select AccountId from BANKING");
		while(rs.next()) {
		if(rs.getInt(1)==Accountid) {
		PreparedStatement pst=con.prepareStatement("update BANKING set balance=balance-? where AccountId=? and balance>=? ");
		pst.setInt(1,amount);
		pst.setInt(2, Accountid);
		pst.setInt(3, amount);
		pst.executeUpdate();
		}
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		//Now perform transaction
		try {
			Connection con;
			con = DBUtil.getConnection();
		System.out.println("Enter AccountID of receiver:");
		int Accountid1=s.nextInt();
		Statement st;
		st = con.createStatement();
		ResultSet rs=st.executeQuery("select AccountId from BANKING");
		while(rs.next()) {
		if(rs.getInt(1)==Accountid1){
		PreparedStatement pst=con.prepareStatement("update BANKING set balance=balance+? where AccountId=? ");
		pst.setInt(1,amount);
		pst.setInt(2, Accountid1);
		pst.executeUpdate();
		System.out.println("Successfully Transfered...........");
		flag=true;
		
	}
}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		if(flag==false) {
			System.out.println("Something went wrong....Check the details once.");
		}
	}
	public List<BankApplication> getAllAccounts(){
		List<BankApplication> bankapplicationlist=new ArrayList<BankApplication>();
		try {
		Connection con=DBUtil.getConnection();
		Statement pst=con.createStatement();
		ResultSet rs=pst.executeQuery("select * from BANKING");
		while(rs.next()) {
			BankApplication b=new BankApplication();
			b.setAccountId(rs.getInt(1));
			b.setName(rs.getString(2));
			b.setMobile(rs.getInt(3));
			b.setCity(rs.getString(4));
			b.setBalance(rs.getInt(5));
			bankapplicationlist.add(b);
			
		}
	}
	catch (Exception e) {
		
		e.printStackTrace();
	}
	
	return bankapplicationlist;
	

}
}
