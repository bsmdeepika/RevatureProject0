package com.revature.bankapp.dao;
import java.util.List;

import com.revature.bankapp.model.BankApplication;

public interface BankAppDAO {
	public void createAccount();
	public void deposite();
	public void withdraw();
	public void transfer();
	public List<BankApplication> getAllAccounts();

}
