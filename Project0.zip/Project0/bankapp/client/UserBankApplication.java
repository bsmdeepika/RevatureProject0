package com.revature.bankapp.client;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.revature.bankapp.controller.BankApplicationController;
import com.revature.bankapp.model.BankApplication;
import com.revature.bankapp.util.DBUtil;

public class UserBankApplication {
	static Logger logger= Logger.getLogger(UserBankApplication.class);
	public static void main(String args[]) {
		Scanner s=new Scanner(System.in);
		System.out.println("************Bank Application**********");
		logger.info("entered in client......");
		BankApplicationController bcontroller=new BankApplicationController();
		System.out.println("1.Deposite"+"       "+"2.Withdraw"+"     "+"3.Transfer"+" "+"4.Create Account");
		System.out.println("Enter your choice:");
		int choice=s.nextInt();
		switch(choice){
			case 1:
				bcontroller.deposite();
				break;
			case 2:
				bcontroller.withdraw();
				break;
			case 3:
				bcontroller.transfer();
				break;
			case 4:
				bcontroller.createAccount();
				break;
			default:
				System.out.println("Enter correct choice");
		}
	
		s.close();
		System.out.println(bcontroller.getAllAccounts());
		List<BankApplication> bankapplicationlist=bcontroller.getAllAccounts();
		
	}

}
